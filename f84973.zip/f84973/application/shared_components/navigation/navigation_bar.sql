prompt --application/shared_components/navigation/navigation_bar
begin
--   Manifest
--     ICON BAR ITEMS: 84973
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.2'
,p_default_workspace_id=>45925276839794708357
,p_default_application_id=>84973
,p_default_id_offset=>0
,p_default_owner=>'WKSP_DAYAHPRACTICE'
);
null;
wwv_flow_imp.component_end;
end;
/
